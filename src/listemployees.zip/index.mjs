import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { ScanCommand } from "@aws-sdk/lib-dynamodb";

const dynamoClient = new DynamoDBClient({ region: process.env.AWS_REGION });



export const handler = async (event) => {
    try {
        // Parameters for scanning the entire table
        const params = {
            TableName: process.env.TABLE_NAME || 'employee_info',
            Limit: 100 // Optional: limit the number of items returned in one request
        };

        // Scan the DynamoDB table
        const command = new ScanCommand(params);
        const data = await dynamoClient.send(command);

        // Return the list of employees
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                employees: data.Items,
                count: data.Count,
                // Include LastEvaluatedKey if there are more items to retrieve
                lastEvaluatedKey: data.LastEvaluatedKey
            })
        };
    } catch (error) {
        console.error('Error scanning employee_info table:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Failed to retrieve employees',
                error: error.message
            })
        };
    }
};