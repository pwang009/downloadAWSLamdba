import _ from 'lodash';
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand } from "@aws-sdk/lib-dynamodb";

const dynamoClient = new DynamoDBClient({ region: process.env.AWS_REGION });

export const handler = async (event) => {
    try {
        const requestBody = JSON.parse(event.body);
        
        // Validate required fields using Lodash
        if (_.isEmpty(requestBody.employeeid) || _.isEmpty(requestBody.FirstName)) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Missing required fields: employeeid and FirstName are required"
                })
            };
        }

        // Create employee object with Lodash
        const employeeItem = _.pickBy({
            employeeid: requestBody.employeeid,
            FirstName: _.capitalize(_.trim(requestBody.FirstName)),
            LastName: requestBody.LastName ? _.capitalize(_.trim(requestBody.LastName)) : null,
            Title: requestBody.Title ? _.startCase(_.toLower(requestBody.Title)) : null,
            Department: requestBody.Department ? _.upperFirst(_.toLower(requestBody.Department)) : null,
            Salary: _.toNumber(requestBody.Salary) || null,
            Email: requestBody.Email ? _.toLower(_.trim(requestBody.Email)) : null,
            createdAt: new Date().toISOString(),
            // Using Lodash to generate a slug for the employee
            employeeSlug: _.kebabCase(`${requestBody.FirstName} ${requestBody.LastName}`)
        }, value => !_.isNil(value)); // Remove null/undefined values

        // Validate email format with Lodash (simple check)
        if (employeeItem.Email && !_.includes(employeeItem.Email, '@')) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Invalid email format"
                })
            };
        }

        // Set up DynamoDB put parameters
        const params = {
            TableName: process.env.TABLE_NAME || 'employee_info',
            Item: employeeItem,
            ConditionExpression: "attribute_not_exists(employeeid)"
        };

        await dynamoClient.send(new PutCommand(params));

        return {
            statusCode: 201,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                "nodejs version": process.version,
                "lodash version": _.VERSION,
                message: "Employee added successfully",
                employee: employeeItem
            })
        };
    } catch (error) {
        console.error('Error adding employee:', error);
        
        if (error.name === 'ConditionalCheckFailedException') {
            return {
                statusCode: 409,
                body: JSON.stringify({
                    message: "Employee with this ID already exists"
                })
            };
        }
        
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to add employee",
                error: error.message
            })
        };
    }
};